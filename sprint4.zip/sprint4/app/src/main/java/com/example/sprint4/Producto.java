package com.example.sprint4;

public class Producto {

    private String elemento;
    private float peso;

    @Override
    public String toString() {
        return elemento;
    }

    public String getElemento() {
        return elemento;
    }

    public void setElemento(String elemento) {
        this.elemento = elemento;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }
}
