package com.example.sprint4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    private EditText eCorreo, eContrasena;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        auth = FirebaseAuth.getInstance();
        eCorreo = findViewById(R.id.etcorreo);
        eContrasena = findViewById(R.id.etcontrasena);

    }
    public void ingresar(View view){
        String correo = eCorreo.getText().toString();
        String contrasena = eContrasena.getText().toString();

        auth.signInWithEmailAndPassword(correo, contrasena).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    Intent reg = new Intent(MainActivity.this, MainPedidos.class);
                    startActivity(reg);
                }else{
                    Toast.makeText(MainActivity.this, "Falló el ingreso", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void registrar(View view){
        String correo = eCorreo.getText().toString();
        String contrasena = eContrasena.getText().toString();

        auth.createUserWithEmailAndPassword(correo, contrasena).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    Toast.makeText( MainActivity.this, "Usuario registrado", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText( MainActivity.this, "Falló el registro", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

}