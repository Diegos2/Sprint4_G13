package com.example.sprint4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.LinkedList;
import java.util.List;

public class MainPedidos extends AppCompatActivity {

    private Spinner elementos;
    private EditText ePeso;
    private ListView eElementos;

    private Producto productoseleccionado;
    private List<Producto> listaproductos;

    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_pedidos);

        ePeso = findViewById(R.id.etPeso);
        elementos = findViewById(R.id.spElementos);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.spElementos, R.layout.myspinner);
        elementos.setAdapter(adapter);
        eElementos = findViewById(R.id.lvElementos);
        iniciarFireDatabase();
        listaproductos = new LinkedList<Producto>();
        listproductos();
        eElementos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                productoseleccionado = (Producto) parent.getItemAtPosition(position);
                //elementos.setAdapter(productoseleccionado.getElemento());
                ePeso.setText(Float.toString(productoseleccionado.getPeso()));
            }
        });
    }

    private void listproductos() {
        databaseReference.child("Productos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaproductos.clear();
                for(DataSnapshot snapshot1 : snapshot.getChildren()){
                    Producto p = snapshot.getValue(Producto.class);
                    listaproductos.add(p);
                    ArrayAdapter adaptador = new ArrayAdapter<Producto>(MainPedidos.this, android.R.layout.simple_list_item_1, listaproductos);
                    eElementos.setAdapter(adaptador);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void iniciarFireDatabase() {
        FirebaseApp.initializeApp(this);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.crud_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        String elemento = elementos.getSelectedItem().toString();
        float peso = Float.parseFloat(ePeso.getText().toString());
        String speso = Float.toString(peso);
        Producto p = new Producto();

        switch (item.getItemId()){
            case R.id.menu_agregar:
                if(elemento.equals("SELECCIONAR") || speso.equals("")){
                    validarDatos(elemento, speso);
                }else{
                    Toast.makeText(this, "Agregar " + elemento, Toast.LENGTH_SHORT).show();
                    p.setElemento(elemento);
                    p.setPeso(peso);

                    databaseReference.child("Productos").child(p.getElemento()).setValue(p);
                }
                break;
            case R.id.menu_actualizar:
                Toast.makeText(this, "Actualizar", Toast.LENGTH_SHORT).show();
                p.setElemento(elemento);
                p.setPeso(peso);
                databaseReference.child("Productos").child(p.getElemento()).setValue(p);
                break;
            case R.id.menu_eliminar:
                p.setElemento(productoseleccionado.getElemento());
                databaseReference.child("Productos").child(p.getElemento()).removeValue();
                Toast.makeText(this, "Actualizando", Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void validarDatos(String ele, String spe) {
        if (ele.equals("SELECCIONAR")){
            Toast.makeText(this, "Seleccione un elemento ", Toast.LENGTH_SHORT).show();
        } else if (spe.equals("")) {
            this.ePeso.setError("Requerid");
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode==event.KEYCODE_BACK){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Realmente desea salir").setPositiveButton("Si", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(Intent.ACTION_MAIN);
                    intent.addCategory(Intent.CATEGORY_HOME);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                }
            }).setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            builder.show();
        }
        return super.onKeyDown(keyCode, event);
    }

    public void salir(View view){
        finish();
    }
}